package com.example.bmi_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
